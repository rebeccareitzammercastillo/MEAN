
module.exports = {
    index: function(req,res){
    }
}