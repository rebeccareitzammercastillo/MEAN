import { Component, OnInit } from '@angular/core';
import {HttpService} from './http.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'public';
  tasksClicked=false;
  showClicked=false;
  tasks:any=[];
  show:any= [];
  constructor(private _httpService: HttpService){}
  ngOnInit(){
    this.getTasksFromService();
    // this.showTaskFromService(id);
  }
  getTasksFromService(){
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {console.log("Got our tasks!", data)
    this.tasks = data;
  });
  }
  showTaskFromService(id:string){
    let observable = this._httpService.showTask(id);
    observable.subscribe(data => {console.log("Got one task!", data)
    this.show= data;
  });
  }
allTasks(): void { 
  this.tasksClicked=true;
  this.getTasksFromService();
}
showTask(id:string):void {
  this.showClicked=true;
  this.showTaskFromService(id);
}
}
