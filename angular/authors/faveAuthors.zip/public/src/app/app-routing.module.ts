import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAuthorComponent } from './create-author/create-author.component';
import { AllAuthorsComponent } from './all-authors/all-authors.component';
import { EditAuthorComponent } from './edit-author/edit-author.component';


const routes: Routes = [
  //all authors
  {path:'', component: AllAuthorsComponent},
  //create a new author
  {path: 'new', component: CreateAuthorComponent},
  //edit an author
  {path: 'edit/:id', component: EditAuthorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
