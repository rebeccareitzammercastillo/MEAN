const mongoose =require('mongoose');

const QuoteSchema = new mongoose.Schema({
    quote: {
        type:String,
        requires: [true, 'Quote is required'], 
        min: [3, 'Quote must be at least characters']
    }
}, {timestamps:true})

const Quote = new mongoose.model('Quote, QuoteSchema')

module.exports={
    Quote:Quote,
    QuoteSchema:QuoteSchema
}