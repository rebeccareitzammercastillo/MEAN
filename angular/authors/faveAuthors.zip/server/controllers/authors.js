const { Author } = require("../models/author")

module.exports = {
    index: function(req,res){
        Author.find()
            .then((data) =>{
                console.log("All authors worked!")
                res.json({authors:data});
            })
            .catch((err) =>{
                res.json(err);
            });
    },
    create: function (req,res){
        let author = new Author()
        author.name= req.body.name
        author.save()
        .then(newAuthor => {
            console.log("this is the controller")
            res.json(newAuthor)
        })
        .catch((err)=>{
            res.json(err);
        });
    },
    edit: function (req, res){
        Author.findOne({_id:req.params.id})
        .then(data => {
            author = data
            author.name = req.body.name
            author.save()
            .then(()=>{
                res.json(data)
            })
        })
        .catch(err => {
            res.json(err)
        })
    },
    show: function (req, res){
        Author.findOne({_id: req.params.id})
        .then(data => {
            res.json(data);
        })
        .catch((err) => {
            res.json(err);
        });
    },
    delete: function (req,res){
        Author.deleteOne({_id: req.params.id})
        .then(() => {
            res.json(`You have removed Author`);
        })
        .catch((err) => {
            res.json(err);
        });
    }

}