module.exports = function(app){
    app.get('/', (reg,res) =>{

    })
}