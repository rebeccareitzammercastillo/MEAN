
module.exports= function(app){

app.get("/", (req, res) => {
    errors = req.flash('errors')
    res.render('index');
})

app.post('/quotes', (req, res) => {
    // console.log(req.body)
    const quote = new Quote();
    quote.name =req.body.name;
    quote.quote=req.body.quote;
    quote.save()
        .then(newQuoteData => {console.log('quote created: ', newQuoteData)
        res.redirect('/quotes')})
        .catch(err => {
            console.log('********************')
            console.log('err:', err.errors.quote)
            if(err.errors.name) {
                req.flash('errors','Name is required')
            }
            if(err.errors.quote) {
                req.flash('errors','Quote is required')
            }
            res.redirect('/')
        })
    })

app.get('/quotes',(req,res) =>{
    Quote.find()
    .sort({createdAt:-1})
    .then(data => {
        console.log('data from .then',data)
        res.render('results', {quotes: data});
    })
    console.log('after .then')
});

}