const express = require("express"),
    app = express(),
    mongoose = require('mongoose'),
    port = 8000,
    server = app.listen(port,() => console.log(`Listening on port ${port}`))

mongoose.connect('mongodb://localhost/spooDash', {useNewUrlParser: true});
const PoodleSchema = new mongoose.Schema({
    name: String,
    color: String,
    age: Number
})
    // create an object that contains methods for mongoose to interface with MongoDB
const Poodle = mongoose.model('Poodle', PoodleSchema);

const session = require('express-session'); //in order to access session
app.use(express.urlencoded({extended:true})); //in order to access POST data
app.use(express.static(__dirname + "/static"));

app.use(session({                           //in order to session. Also must install "npm install express-session"
    secret: 'keyboardkitten',
    resave: false,
    saveUninitialized:true,
    cookie: {maxAge: 60000}
}))

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

app.get('/', (req, res) => {  
    Poodle.find()
        .then(data => res.render("index", {poodles: data}))
        .catch(err => res.json(err));
});

app.get('/poodles/new', (req,res) =>{
    res.render('newPoodle');
})

app.post('/poodles', (req,res)=>{
    const poodle = new Poodle();
    poodle.name = req.body.name;
    poodle.color = req.body.color;
    poodle.age = req.body.age;
    poodle.save()
        .then(newPoodleData => console.log('poodle created:', newPoodleData))
        .catch(err=> console.log(err));
    res.redirect('/')
})

app.get('/poodles/:id', (req,res)=>{
    Poodle.findOne({_id:req.params.id})
    .then(data => res.render("onePoodle", {poodles: data}))
    .catch(err => res.json(err));
})

app.get('/poodles/edit/:id', (req,res)=>{
    Poodle.findOne({_id:req.params.id})
    .then(data => res.render("editPoodle", {poodles: data}))
    .catch(err => res.json(err));
})

app.post('/poodles/:id', (req,res)=>{
    Poodle.findOne({_id:req.params.id})
    .then(data => {
        poodle = data
        poodle.name = req.body.name
        poodle.color= req.body.color
        poodle.age = req.body.age
        poodle.save()
        .then(()=>{
            res.redirect(`/poodles/${req.params.id}`)
        })
    })
    .catch(err => {
        console.log('err:', err)
        res.redirect(`/poodles/edit/${req.params.id}`)
    })
})

app.get('/poodles/destroy/:id', (req,res) => {
    Poodle.remove({_id:req.params.id,})
    .then(()=>{
        res.redirect('/')
    })
})